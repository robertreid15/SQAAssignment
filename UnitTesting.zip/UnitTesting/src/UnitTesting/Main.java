package UnitTesting;
public class Main {
  public static void main(String[] args) {
    TestRunner tr = new TestRunner();
    tr.main();
  }
}
