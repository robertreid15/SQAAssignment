package UnitTesting;
class MyMath {
  private int a, b;
  
  MyMath(int a, int b) {
    this.a = a;
    this.b = b;
  }
  
  public int practice() {
    return a+b;
  }
  
}